"""
Leave app configuration
"""
from django.apps import AppConfig


class LeaveConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.leave'
    verbose_name = 'Leave Management'
    
    def ready(self):
        """Import signals when app is ready"""
        import apps.leave.signals
